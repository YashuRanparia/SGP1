let closetran = document.getElementById("closebtntran");

closetran.addEventListener("click",()=>{
    location.href = "link_css.html";
})