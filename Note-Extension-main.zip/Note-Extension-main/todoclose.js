let btn = document.getElementById("cbtn");

btn.addEventListener("click",()=>{
    location.href="link_css.html";
})