let closedict = document.getElementById("closedict");
closedict.addEventListener("click",()=>{
    location.href = "link_css.html";
})